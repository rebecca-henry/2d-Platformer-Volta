﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using TMPro;

public class LetterCollection : MonoBehaviour
{
    public static LetterCollection main;
    //public Letters letter;
    public static TextMeshProUGUI displayCollection;
    protected Player player;
    // public string collection = "";
    //  public Letters letter;

    private void Awake()
    {
        main = GetComponent<LetterCollection>();
        displayCollection = GetComponent<TextMeshProUGUI>();
        //  player = GetComponent<Player>();
    }

    public virtual void UpdateCollection(GameObject playerCollecting)
    {
        player = playerCollecting.GetComponent<Player>();
        displayCollection = GetComponent<TMPro.TextMeshProUGUI>();
        if (player.gameObject == null)
        {
            return;
        }
        //  player = playerCollecting.GetComponent<Player>();
        string collection = player.gameObject.GetComponent<Player>().letterCollection;
        // letter = let.gameObject.GetComponent<Letters>();
        string wordBlanks = "";
        //  collection += letter.GetComponent<Letters>().letter;
        string fullWord = player.gameObject.GetComponent<Player>().word;
        for (int i = 0; i < fullWord.Length; i++)
        {
            bool added = false;
            for (int j = 0; j < collection.Length; j++)
            {
                if ((fullWord[i]).Equals(collection[j]))
                {
                    wordBlanks += fullWord[i];
                    added = true;
                }
            }
            if (!added)
            {
                wordBlanks += "_";
            }

        }
        displayCollection.SetText("");
        displayCollection.SetText(wordBlanks);
    }


    // Start is called before the first frame update
    void Start()
    {
        // player = GetComponent<Player>();
        // displayCollection.text = "_____";

        //collection = "";

    }

    // Update is called once per frame
    void Update()
    {

    }
}
