﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Unhide : MonoBehaviour
{
    // Start is called before the first frame update
   // public static List<GameObject> hidden = new List<GameObject>();
    void Start()
    {

    }

    // Update is called once per frame
    void Update()
    {
        
    }
}
