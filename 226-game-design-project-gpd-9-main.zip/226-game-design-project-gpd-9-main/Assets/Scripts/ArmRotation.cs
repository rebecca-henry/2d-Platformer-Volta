﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class ArmRotation : MonoBehaviour
{
    public int rotationOffset = 90;
    //unity also has a function called transform.lookat 

    // Start is called before the first frame update

    // Update is called once per frame
    void Update()
    {
        Vector3 difference = Camera.main.ScreenToWorldPoint(Input.mousePosition) - transform.position; // subtracting the position of the player from the mouse position 
        difference.Normalize (); //normalizing the vector- means that the sum of the vector is equal to one

        // find angle btween (0,0) and the difference angle and converting from radians to degrees 
        float rotZ = Mathf.Atan2(difference.y, difference.x) * Mathf.Rad2Deg; // find the angle in degrees 
        transform.rotation = Quaternion.Euler(0f, 0f, rotZ + rotationOffset);


    }
}
