﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class GameMaster : MonoBehaviour
{
    //singleton pattern: makes sure that there is only one instance of a class in any given scene 
    public static GameMaster gm;
    private AudioSource audioSource;

    void Start ()
    {
        if (gm == null)
        {
            gm = GameObject.FindGameObjectWithTag("GM").GetComponent<GameMaster>();
        }
    }

    public Transform playerPrefab;
    public Transform spawnPoint;
    public int spawnDelay;
   

    public IEnumerator RespawnPlayer()
    {
        yield return new WaitForSeconds (spawnDelay);
        Instantiate(playerPrefab, spawnPoint.position, spawnPoint.rotation);
    }
    public static void KillPlayer (Player player)
    {
        Destroy(player.gameObject);
        gm.StartCoroutine (gm.RespawnPlayer());
    }
    public void PlaySoundFX(AudioClip audioClip)
    {
        audioSource.PlayOneShot(audioClip);
    }
   // void IPlayerEvents.OnButterflyCollected(int numCollected)
  //  {
        
  //      if(numCollected == 3)
 //       {
 //           foreach (Letters l in hiddenLetters)
  //          {
                //Debug.Log("Showing I");
  //              l.gameObject.GetComponent<Renderer>().enabled = true;
  //          }
  //      }
  //  }
    

}
