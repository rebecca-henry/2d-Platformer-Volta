﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.EventSystems;

public class Player : MonoBehaviour
{
    [System.Serializable]
    public class PlayerStats
    {
        public int Health = 100;
    }
    public string letterCollection = "";
    public string word = "";
    public PlayerStats playerStats = new PlayerStats();
   // public int butterfliesCollected = 0;
    public int fallBoundary = -20;

   void Start()
    {
        letterCollection = "";
        word = "";
    }

    void Update()
    {
        if (transform.position.y <= fallBoundary) //falling out of the game 
            DamagePlayer(9999999);
    }

    public void DamagePlayer(int damage)
    {
        playerStats.Health -= damage;
        if (playerStats.Health <= 0)
        {
            GameMaster.KillPlayer(this);//send over player 
            Debug.Log("KILL PLAYER");
        }

    }
    public void AddLetter(string letter)
    {
        letterCollection += letter;
    }


}
