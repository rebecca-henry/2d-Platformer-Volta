﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
public class Letters : MonoBehaviour
{
    public LetterCollection letterCollection;
    public string letter;
    public string word;
    public AudioClip soundEffect;
    public GameObject specialEffect;

    protected Player player;

    protected SpriteRenderer spriteRenderer;

    public enum LetterStatus
    {
        IsAttracting,
        IsCollected,
        IsExpiring
    }

    public LetterStatus letterStatus;

    protected virtual void Awake()
    {
        spriteRenderer = GetComponent<SpriteRenderer>();
    }

    protected virtual void Start()
    {

        letterStatus = LetterStatus.IsAttracting;
    }

    public virtual void OnTriggerEnter2D(Collider2D other)
    {
        LetterCollected(other.gameObject);
    }

    protected virtual void LetterCollected(GameObject gameObjectCollectingLetter)
    {
        if (gameObjectCollectingLetter.tag != "Player")
        {
            return;
        }
        letterStatus = LetterStatus.IsCollected;
        

        player = gameObjectCollectingLetter.GetComponent<Player>();
       // player.letterCollection += letter;
        //LetterCollection.main.UpdateCollection(gameObjectCollectingLetter);

        gameObject.transform.parent = player.gameObject.transform;
        gameObject.transform.position = player.gameObject.transform.position;


        LetterEffects();
        LetterPayload();
    }
    protected virtual void LetterEffects()
    {
        if (specialEffect != null)
        {
            Instantiate(specialEffect, transform.position, transform.rotation, transform);
        }
        if (soundEffect != null)
        {
            GameMaster.gm.PlaySoundFX(soundEffect);
        }
    }
    protected virtual void LetterPayload()
    {
        Debug.Log("Letter collected, issuing payload for: " + gameObject.name);
        LetterExpired();
    }

    protected virtual void LetterExpired()
    {
        if (letterStatus == LetterStatus.IsExpiring)
        {
            return;
        }
        letterStatus = LetterStatus.IsExpiring;

        Debug.Log("Removing letter from the scene" + gameObject.name);
        Destroy(gameObject, 1f);
    }
}