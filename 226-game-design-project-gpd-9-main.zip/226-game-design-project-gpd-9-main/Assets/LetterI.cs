﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.EventSystems;

public class LetterI : Letters
{
    protected override void Awake()
    {
        this.gameObject.GetComponent<Renderer>().enabled = false;
       
    }
    protected override void Start()
    {
       
    }

    protected override void LetterPayload()
    {
        player.AddLetter(letter);
        base.LetterPayload();

    }
    

}

