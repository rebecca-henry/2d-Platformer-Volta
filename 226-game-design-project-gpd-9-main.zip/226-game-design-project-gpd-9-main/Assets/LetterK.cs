﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.EventSystems;

public class LetterK : Letters
{
    protected override void LetterPayload()
    {
        player.AddLetter(letter);
        base.LetterPayload();
        
    }
   // protected override void LetterExpired()
  //  {
  //      base.LetterExpired();
  //  }

}
