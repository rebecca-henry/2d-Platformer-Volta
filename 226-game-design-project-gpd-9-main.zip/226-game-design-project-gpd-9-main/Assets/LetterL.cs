﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class LetterL : Letters
{
    protected override void Awake()
    {
        this.gameObject.GetComponent<Renderer>().enabled = false;

    }
    protected override void Start()
    {

    }

    protected override void LetterPayload()
    {
        player.AddLetter(letter);
        base.LetterPayload();

    }
}
