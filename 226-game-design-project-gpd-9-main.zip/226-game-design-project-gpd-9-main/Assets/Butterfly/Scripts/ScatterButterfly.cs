﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

//Butterfly flies in random direction when hit by player

public class ScatterButterfly : MonoBehaviour
{
    // Start is called before the first frame update
    void Start()
    {
        
    }

    // Update is called once per frame
    void Update()
    {
        
    }
}
