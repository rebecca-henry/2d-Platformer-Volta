﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

//Has butterflies moving around screen

public class MoveButterfly : MonoBehaviour
{   
    private Rigidbody2D b_Rigidbody2D;
    public float xSpeed;
    public float ySpeed;
    public float maxX;
    public float minX;
    public float maxY;
    public float minY;
    private float startX;
    private float startY;
    private Transform trans;
    private bool faceLeft = true;

    // Start is called before the first frame update
    void Start()
    {
        b_Rigidbody2D = GetComponent<Rigidbody2D>();
        trans = GetComponent<Transform>();
        startX = b_Rigidbody2D.position.x;
        startY = b_Rigidbody2D.position.y;
    }

    // Update is called once per frame
    void Update()
    {
        if (faceLeft && trans.localScale.x < 0) {
            faceLeft = false;
        }
        if (xSpeed >= 0 && faceLeft){
            Flip();
        }
        else if (xSpeed < 0 && !faceLeft && trans.localScale.x > 0) {
            Flip();
        }
        MoveCircle();
    }

    void MoveCircle()
    {
        if (b_Rigidbody2D.position.x - startX > maxX) {
            Flip();
            xSpeed = -xSpeed;
        }
        else if (b_Rigidbody2D.position.x - startX < minX) {
            Flip();
            xSpeed = -xSpeed;
        }
        if (b_Rigidbody2D.position.y - startY > maxY) {
            ySpeed = -ySpeed;
        }
        else if (b_Rigidbody2D.position.y - startY < minY) {
            ySpeed = -ySpeed;
        }
        Move(xSpeed,ySpeed);
    }

    void Move(float x, float y)
    {   
        b_Rigidbody2D.position = new Vector2(b_Rigidbody2D.position.x + x, b_Rigidbody2D.position.y + y);
    }

    void Flip()
    {
        trans.localScale = new Vector3(-trans.localScale.x,trans.localScale.y, 0f);
        if (faceLeft == true) {
            faceLeft = false;
        }
        else if (faceLeft == false) {
            faceLeft = true;
        }
    }
}