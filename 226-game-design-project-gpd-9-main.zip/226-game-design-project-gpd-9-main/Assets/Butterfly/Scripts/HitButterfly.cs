﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.EventSystems;


//Adjusts counter +1
//Removes butterfly from scene
//Noise plays

public class HitButterfly : MonoBehaviour
{
    public int bCounter;
    protected Player player;
    public static List<GameObject> hitButterflies = new List<GameObject>();
    public static GameObject[] hidden;

    // Start is called before the first frame update
    void Start()
    {
       
    }

    // Update is called once per frame
    void Update()
    {
        
    }
    //
    private void OnCollisionEnter2D (Collision2D col){
        player = col.gameObject.GetComponent<Player>();

        if (hitButterflies.IndexOf(col.gameObject) == -1 && col.gameObject.tag == "Butterfly" && gameObject.tag == "Player")
        {   
            Destroy(col.gameObject);
            bCounter = bCounter + 1;
            hitButterflies.Add(col.gameObject);
        }
        if (bCounter == 3)
        {
            if (hidden == null)
            {
                hidden = GameObject.FindGameObjectsWithTag("Hidden");
            }
            foreach (GameObject go in hidden)
            {
                if(go != null)
                {
                    go.GetComponent<Renderer>().enabled = true;
                }
                
               
            }
        }


    }
   
}
