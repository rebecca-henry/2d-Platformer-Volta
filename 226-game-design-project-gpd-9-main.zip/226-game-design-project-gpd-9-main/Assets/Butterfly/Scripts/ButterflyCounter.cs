﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class ButterflyCounter : MonoBehaviour
{
    public HitButterfly player;
    public bool hit3;
    private int bCountTotal;
    private int currentHit;
    private int lastHit;

    // Start is called before the first frame update
    void Start()
    {   
    }

    // Update is called once per frame
    void Update()
    {
        if (GameObject.Find("CharacterRobotBoy")!= null && GameObject.Find("CharacterRobotBoy").GetComponent<HitButterfly>()!=null)
        {
            player = GameObject.Find("CharacterRobotBoy").GetComponent<HitButterfly>();
        }
        else if (GameObject.Find("CharacterRobotBoy(Clone)")!= null && GameObject.Find("CharacterRobotBoy(Clone)").GetComponent<HitButterfly>()!=null) 
        {
            player = GameObject.Find("CharacterRobotBoy(Clone)").GetComponent<HitButterfly>();
        }
        currentHit = player.bCounter;
        if (currentHit > lastHit)
        {
            bCountTotal = bCountTotal + (currentHit - lastHit);
        }
        lastHit = player.bCounter;
        if (bCountTotal >= 3) 
        {
            hit3 = true;
        }
    }
}
